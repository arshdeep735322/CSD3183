package com.example.lotteryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class winner extends AppCompatActivity {
     int total,win;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_winner);
        Bundle bundle=getIntent().getExtras();
        total=bundle.getInt("total");
        win=bundle.getInt("win");

    }
}
