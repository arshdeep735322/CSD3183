package com.example.lotteryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends Activity {
     Button quick,pick,encore;
     TextView totalmoney,won,loss,quotes;
     int total=6000000,win=60,los=0,extra;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        quick=(Button)findViewById(R.id.quickpick);
        pick=(Button)findViewById(R.id.pick);
        Bundle b=new Bundle();


        totalmoney=(TextView)findViewById(R.id.totalmoney);
        won=(TextView)findViewById(R.id.youwon);
        loss=(TextView)findViewById(R.id.loss);
        quotes=(TextView)findViewById(R.id.quotes);



        quick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Main2Activity.this, com.example.lotteryapp.quick.class);
                Bundle bundle=new Bundle();
                bundle.putInt("total",total);
                bundle.putInt("win",win);
                bundle.putInt("loss",los);
                intent.putExtras(bundle);
                startActivityForResult(intent,123);

            }
        });
        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Main2Activity.this,pick.class);
                Bundle bundle=new Bundle();
                bundle.putInt("total",total);
                bundle.putInt("win",win);
                bundle.putInt("loss",los);
                intent.putExtras(bundle);
                startActivityForResult(intent,456);
            }
        });
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        System.out.println(data);

        if (requestCode == 123 ) {

            System.out.println(data);
            Bundle b=data.getExtras();
            total=b.getInt("total");
            win=b.getInt("win");
            los=b.getInt("loss");
            totalmoney.setText(Integer.toString(total));
            System.out.println(win);
            won.setText(Integer.toString(win));
            loss.setText(Integer.toString(los));
            Toast.makeText(this,"i am here",Toast.LENGTH_LONG).show();
        }

        if (requestCode == 456 ) {

                Bundle b=data.getExtras();
                total=b.getInt("total");
                win=b.getInt("win");
                los=b.getInt("loss");
                totalmoney.setText(Integer.toString(total));
                System.out.println(total);
                won.setText(Integer.toString(win));
                loss.setText(Integer.toString(los));

        }
    }

    @Override
    public void onBackPressed() {
        System.exit(0);
        super.onBackPressed();
    }
}
