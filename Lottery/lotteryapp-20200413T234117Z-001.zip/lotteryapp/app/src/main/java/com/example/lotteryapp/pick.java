package com.example.lotteryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

public class pick extends AppCompatActivity {
     EditText e1,e2,e3,e4,e5,e6,e7;
     TextView t1,t2,t3;
    int total,win,los;
     Button gen,shuff;
     String ars[]=new String[7];
     String s[]={"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20",
             "21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39","40",
             "41","42","43","44","45","46","47","48","49","50"};
     String s2,s1,s3,s4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick);

        Bundle bundle=getIntent().getExtras();
        total=bundle.getInt("total");
        win=bundle.getInt("win");
        los=bundle.getInt("loss");

         e1=(EditText)findViewById(R.id.f1);
        e2=(EditText)findViewById(R.id.f2);
        e3=(EditText)findViewById(R.id.f3);
        e4=(EditText)findViewById(R.id.f4);
        e5=(EditText)findViewById(R.id.f5);
        e6=(EditText)findViewById(R.id.f6);
        e7=(EditText)findViewById(R.id.f7);
        gen=(Button)findViewById(R.id.butt);
        t1=(TextView)findViewById(R.id.wining);
        ars[0]=e1.getText().toString();
        ars[1]=e1.getText().toString();
        ars[2]=e1.getText().toString();
        ars[3]=e1.getText().toString();
        ars[4]=e1.getText().toString();
        ars[5]=e1.getText().toString();
        ars[6]=e1.getText().toString();
        s1=e1.getText().toString()+e2.getText().toString()+e3.getText().toString()+e4.getText().toString()+e5.getText().toString()
                +e6.getText().toString()+e7.getText().toString();
         if(win>4){
        gen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                los=los+5;
                win=win-5;
                s2=generateran();
                if(s2.equals(s1))
                {
                    Toast.makeText(getApplicationContext(),"you won",Toast.LENGTH_LONG).show();
                    win=win+3000000;
                    total=total-3000000;
                }
                else {
                    Toast.makeText(getApplicationContext(),"you lost",Toast.LENGTH_LONG).show();
                }
                if(win<4)
                {
                    Toast.makeText(pick.this, "You dont have enough money to play", Toast.LENGTH_SHORT).show();
                    onBackPressed();
                }
            }
        });}
         else
         {
             Toast.makeText(getApplicationContext(),"you dont have enough money to play",Toast.LENGTH_LONG).show();
         }
        if(win<5)
        {
            Intent intent = new Intent(getApplicationContext(),Main2Activity.class);
            Bundle bundle1=new Bundle();
            bundle1.putInt("total",total);
            bundle1.putInt("win",total);
            bundle1.putInt("loss",total);
            intent.putExtras(bundle);
            setResult(789, intent);
            finish();
        }
    }
    public String generateran()
    {
        Collections.shuffle(Arrays.asList(s));
        s2=s[0]+" "+s[1]+" "+s[2]+" "+s[3]+" "+s[4]+" "+s[5]+" "+s[6]+" "+s[7];
        t1.setText(s2);
        return s2;

    }
    public String generateranuser()
    {
        Collections.shuffle(Arrays.asList(ars));
        s3=ars[0]+" "+ars[1]+" "+ars[2]+" "+ars[3]+" "+ars[4]+" "+ars[5]+" "+ars[6]+" "+ars[7];

        return s3;

    }

    @Override
    public void onBackPressed() {

        Intent intent = new Intent(getApplicationContext(),Main2Activity.class);
        Bundle bundle=new Bundle();
        bundle.putInt("total",total);
        bundle.putInt("win",win);
        bundle.putInt("loss",los);
        intent.putExtras(bundle);
        setResult(789, intent);
        super.onBackPressed();
        finish();
    }
}
