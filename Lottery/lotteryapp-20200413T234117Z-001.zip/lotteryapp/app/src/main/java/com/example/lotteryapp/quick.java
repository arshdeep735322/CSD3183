package com.example.lotteryapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

public class quick extends AppCompatActivity {
    TextView t1,t2,t3,t4;
    Button gennerate;
    int total,win,los;
    String s[]={"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20",
            "21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39","40",
            "41","42","43","44","45","46","47","48","49","50"};
    String s2,s1,s3,s4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quick);
        Bundle bundle = getIntent().getExtras();
        total=bundle.getInt("total");
        win=bundle.getInt("win");
        los=bundle.getInt("loss");
        t1=(TextView)findViewById(R.id.first);
        t2=(TextView)findViewById((R.id.second));
        t3=(TextView)findViewById(R.id.third);
        t4=(TextView)findViewById(R.id.winnum);
        gennerate=(Button)findViewById(R.id.generate);

        s4=generateran();
        t4.setText(s4);
        if(win>4)
        {
        gennerate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                los=los+5;
                win=win-5;
                s1=generateran();
                s2=generateran();
                s3=generateran();

                t1.setText(s1);
                t2.setText(s2);
                t3.setText(s3);
                System.out.println(win);

                if (s4.equals(s2)||s4.equals(s1)||s4.equals(s3))
                {
                    total=total-3000000;
                    win=win+3000000;

                    Toast.makeText(getApplicationContext(),"YOU WON A LOTTERY",Toast.LENGTH_LONG).show();
                }
                else
                {

                    Toast.makeText(getApplicationContext(),"YOU LOST",Toast.LENGTH_LONG).show();

                }
                if(win<4)
                {
                    Toast.makeText(getApplicationContext(),"You dont have enough money to play",Toast.LENGTH_LONG).show();
                    onBackPressed();


                }

            }
        });}
        else{
            Toast.makeText(this,"You dont have enough money to play",Toast.LENGTH_LONG).show();
            gennerate.setEnabled(false);
        }
    }
    public String generateran()
    {
        Collections.shuffle(Arrays.asList(s));
        s2=s[0]+" "+s[1]+" "+s[2]+" "+s[3]+" "+s[4]+" "+s[5]+" "+s[6]+" "+s[7];
        return s2;

    }

    @Override
    public void onBackPressed() {

        Intent intent = new Intent(this,Main2Activity.class);
        Bundle bundle=new Bundle();
        bundle.putInt("total",total);
        bundle.putInt("win",win);
        bundle.putInt("loss",los);
        intent.putExtras(bundle);
        System.out.println("kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk"+win);
        System.out.println(intent);
        setResult(234, intent);
        super.onBackPressed();
        finish();

    }
}
